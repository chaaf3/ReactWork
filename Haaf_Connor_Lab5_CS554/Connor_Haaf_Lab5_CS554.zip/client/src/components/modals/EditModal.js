import React, { useState } from "react";
import "../App.css";

function EditModal() {
  return <div className="App">Edit Modal</div>;
}

export default EditModal;
