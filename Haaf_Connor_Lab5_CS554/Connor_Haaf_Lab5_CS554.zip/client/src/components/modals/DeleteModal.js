import React from "react";
import "../App.css";

function DeleteModal() {
  return <div className="App">Delete Modal</div>;
}

export default DeleteModal;
