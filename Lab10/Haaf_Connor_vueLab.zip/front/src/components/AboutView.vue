<template>
  <div class="about">
    <h1>This is a Vue web application on Marvel!</h1>
  </div>
</template>

