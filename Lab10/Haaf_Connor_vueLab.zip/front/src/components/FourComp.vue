<template>
    <div class="404">
      <h1>404</h1>
    </div>
  </template>
<script>
export default {
    name: "FourComp",
};
</script>
  