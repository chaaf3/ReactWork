<script setup>
import IndividualComic from "../components/IndividualComic.vue";
</script>

<template>
  <main>
    <IndividualComic />
  </main>
</template>