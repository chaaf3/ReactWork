<script setup>
import IndividualStory from "../components/IndividualStory.vue";
</script>

<template>
  <main>
    <IndividualStory />
  </main>
</template>