<script setup>
import StoryList from "../components/StoryList.vue";
</script>

<template>
  <main>
    <StoryList />
  </main>
</template>