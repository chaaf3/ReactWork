<script setup>
import ComicList from "../components/ComicList.vue";
</script>

<template>
  <main>
    <ComicList />
  </main>
</template>