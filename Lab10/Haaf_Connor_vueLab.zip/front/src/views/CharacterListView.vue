<script setup>
import CharacterList from "../components/CharacterList.vue";
</script>

<template>
  <main>
    <CharacterList />
  </main>
</template>