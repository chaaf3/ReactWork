<script setup>
import IndividualCharacter from "../components/IndividualCharacter.vue";
</script>

<template>
  <main>
    <IndividualCharacter />
  </main>
</template>