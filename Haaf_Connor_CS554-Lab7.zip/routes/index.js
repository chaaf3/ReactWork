const path = require("path");
const constructorMethod = (app) => {
  app.get("/", (req, res) => {
    res.sendFile(path.resolve("public/index.html"));
  });
  app.get("*", (req, res) => {
    res.status(404).sendFile(path.resolve("public/404.html"));
  });
};

module.exports = constructorMethod;
