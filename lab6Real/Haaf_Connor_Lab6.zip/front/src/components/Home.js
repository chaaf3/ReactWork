import queries from "../queries";
import React, { useEffect, useState } from "react";

function Home() {
  return (
    <div>
      <h1>Pokemon Lab</h1>
      <p>
        Welcom to the Pokemon lab, here you can simulate trainers and make some
        teams.
      </p>
    </div>
  );
}
export default Home;
