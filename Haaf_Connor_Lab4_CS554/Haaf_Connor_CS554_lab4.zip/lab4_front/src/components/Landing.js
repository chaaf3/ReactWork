import React from "react";
import CharacterList from "./CharacterList";
import Character from "./Character";
import { BrowserRouter as Router, Route, Link, Routes } from "react-router-dom";

function Landing() {
  return (
    <div className="App">
      <p>welcom to the react app that has marvel Data</p>
    </div>
  );
}

export default Landing;
